# Dummy WSUS Proxy

## Info

- Workaround for old Windows operating systems to continue running Windows Update

https://support.microsoft.com/en-us/help/4569557/windows-update-sha-1-based-endpoints-discontinued

- WSUS Proxy allow to scan against Windows Update SHA-2 service endpoints,
using PHP and OpenSSL which support TLS 1.2 protocol and modern cipher suites

______________________________


## Requirements

- Host OS: Windows XP / Server 2003 or later

- Microsoft Visual C++ 2012 Redistributable (x86)
https://download.microsoft.com/download/1/6/B/16B06F60-3B20-4FF2-B699-5E9B7962F9AE/VSU_4/vcredist_x86.exe

- Latest Windows Update Agent 7.6.7600.256
x86
http://download.windowsupdate.com/windowsupdate/redist/standalone/7.6.7600.320/WindowsUpdateAgent-7.6-x86.exe
x64
http://download.windowsupdate.com/windowsupdate/redist/standalone/7.6.7600.320/WindowsUpdateAgent-7.6-x64.exe

- Root Certificates update
https://raw.githubusercontent.com/stdin82/htfx/master/NT5/rootsupd.exe

- Internet Explorer 7/8, or Microsoft IDN Mitigation APIs
x86
https://raw.githubusercontent.com/stdin82/htfx/master/NT5/idndl.x86.exe
x64
https://raw.githubusercontent.com/stdin82/htfx/master/NT5/idndl.amd64.exe

- Windows Update MiniTool, to scan against WSUS
WU/MU via Internet Explorer scan against windowsupdate servers directly and fail

______________________________


## How To Use

- Install requirements and restart the system

- Extract and place this pack into folder with simple path

- Execute Add_wsus.cmd

- Execute Run_wsus.cmd and Unblock Firewall access for PHP

- Run Windows Update MiniTool and scan (Update service: Windows Server Update Service)

- When finished, close PHP cmd window

- If you want to remove WSUS support, execute Remove_wsus.cmd

______________________________


## Credits

- Dummy WSUS
https://github.com/whatever127/dummywsus

- IMI Kurwica WSUS Proxy mod
@mspaintmsi

- PHP 5.6 for Windows XP/2003
http://www.lindasc.com/php/

- OpenSSL 1.0.2u binaries
https://github.com/IndySockets/OpenSSL-Binaries

- Windows Update MiniTool
https://www.wilderssecurity.com/threads/380535/
https://www.mirrored.to/files/YMZZIJ58/
https://forums.mydigitallife.net/threads/64939/

- Project Scripts: abbodi1406
